<?php
require('connection.php');
$vote = $_REQUEST['vote'];

session_start();
mysql_query("UPDATE tbCandidates SET candidate_cvotes=candidate_cvotes+1 WHERE candidate_name='$vote'");
$query1 = "INSERT INTO `user_restrict` (`id`, `members_id`, `position`,`status`) VALUES ('','{$_SESSION["member_id"]}', '{$_SESSION["pos"]}', '1')";
mysql_query($query1);

mysql_close($con);
?> 
